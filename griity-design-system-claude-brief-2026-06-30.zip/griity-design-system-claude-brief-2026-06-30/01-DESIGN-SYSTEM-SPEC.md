# GRIITY Design System Spec

## 1. System Role

The Griity design system is the durable visual and interaction language for the Griity organization. It currently powers the public marketing website and should be extended consistently into decks, reports, admin UI, landing pages, growth-audit flows, and social/content assets.

It must make Griity feel like a **Marketing Operator-led growth partner**, not a generic digital agency or SaaS dashboard.

## 2. Brand Positioning Translated to Design

| Brand idea | Design translation |
|---|---|
| Diagnose before scale | Clear hierarchy, diagnostic cards, system maps, bottleneck labels, evidence-first modules |
| Operator-led growth partner | Structured layouts, mono labels, direct CTA flow, no decorative clutter |
| Premium but practical | Navy/gold palette, warm surfaces, restrained shadows, clean typography |
| Indonesian market-native | Bahasa-first copy rhythm with natural English e-commerce terms |
| Data-aware but human | Metrics/proof cards, charts used sparingly, warm editorial spacing |

## 3. Visual Principles

1. **Operator-grade clarity** — every section must help a founder understand a problem, proof point, or next step.
2. **Premium but practical** — navy/gold warmth, business credibility, not glossy generic SaaS.
3. **System-first UI** — reuse tokens/components before inventing one-off styles.
4. **Evidence-led growth** — support metrics, diagnosis, and CTA flow; no fake data decoration.
5. **Bahasa-first, commerce-native** — body copy supports Indonesian and English variants; keep technical terms natural.
6. **Conversion with restraint** — one primary CTA per section, clear next action, no loud growth-hack styling.

## 4. Core Look

- Deep navy hero/background areas.
- Warm off-white page background.
- Gold primary CTA/accent.
- White rounded cards with subtle border/shadow.
- Mono micro-labels/chips for system/operator feel.
- Line-only SVG/Lucide-style icons.
- No emoji in website/public UI.

## 5. Color System

### Core tokens

| Token | Value | Role |
|---|---:|---|
| `--bg` | `#F7F4EE` | Warm page background |
| `--surface` | `#FFFFFF` | Cards/surfaces |
| `--navy` | `#1A2C50` | Primary brand navy, headings, nav, dark section base |
| `--navy-deep` | `#111E38` | Deep hero/navy gradient |
| `--ink` | `#1A2C50` | Heading/strong body text |
| `--body-c` | `#4A5874` | Body text |
| `--muted` | `#8593AC` | Captions/micro labels |
| `--line` | `rgba(26,44,80,0.10)` | Standard border line |
| `--line-strong` | `rgba(26,44,80,0.16)` | Stronger divider/border |
| `--gold` | `#F6A404` | Primary CTA/accent |
| `--gold-deep` | `#D98E02` | Gold text/accent state |
| `--signal` | `#1F8A5B` | Positive/success metric |
| `--error` | `#E0533D` | Error/risk/negative diagnostic |
| `--chip-bg` | `rgba(26,44,80,0.045)` | Ghost chip background |

### Rules

- Use CSS variables/tokens, not raw hex, in implementation.
- Gold is for CTA/accent, not broad backgrounds.
- `--error` is for diagnostic/risk context, not generic decoration.
- Dark navy surfaces should be limited: hero, audit CTA band, footer CTA, occasional proof modules.
- Do not add new brand colors without documenting role and accessibility.

## 6. Typography

| Role | Font | Usage |
|---|---|---|
| UI/body/headings | Plus Jakarta Sans | Main website and brand typography |
| Mono labels/metrics | IBM Plex Mono | Kicker, microlabel, chip, metric labels, code-like labels |

### Scale guidance

| Role | Size/weight | Rule |
|---|---|---|
| H1 | 48–56px desktop, 800, line-height 1.05–1.1 | One per page; one idea |
| H2 | 32–40px desktop, 800, line-height 1.15 | State problem or promise |
| H3/Card title | 18–24px, 800 | Strong scan point inside cards |
| Body | 15–17px, line-height 1.65–1.75 | Max 2 sentences per paragraph on mobile |
| Kicker | 12px mono, 600, uppercase, tracking 0.18em | Above H2 only |
| Microlabel | 10px mono, 600, uppercase, tracking 0.14em | Inside cards/modules |
| Metric | 40–72px mono, 600 | Proof numbers; never more than 3 together |

## 7. Layout & Spacing

- Default container: max-width equivalent of `max-w-7xl` with responsive side padding.
- Use warm off-white section rhythm and white card modules.
- Use navy sections sparingly for conversion and emphasis.
- Use flow dividers between light sections when it improves rhythm.
- Avoid making every section a card grid; alternate card grids, narrative lists, diagnostic panels, proof strips, and CTA bands.
- Mobile: maintain sticky CTA bottom padding and 44px minimum touch targets.

## 8. Shapes, Elevation, and Surfaces

| Element | Radius | Surface/elevation |
|---|---:|---|
| System card | 18px | White, `--line`, subtle long shadow |
| Primary/ghost button | 14px | Gold or transparent outline |
| Chip | 999px | Mono uppercase pill |
| Icon tile | 12–16px | Gold-tinted or navy-tinted background |
| Large feature panel | 24–28px | Used for case studies/CTA panels |

Base card shadow:

```css
box-shadow: 0 1px 2px rgba(26,44,80,0.04), 0 16px 40px -28px rgba(26,44,80,0.25);
```

## 9. Component System

### Buttons

- `btn-primary`: gold background, navy text, strong conversion CTA.
- `btn-ghost-navy`: secondary action on light surfaces.
- `btn-ghost-dark`: secondary action on navy surfaces.

Rules:

- One primary CTA per section.
- Avoid generic labels like “Contact Us” or “Click Here”.
- Preferred CTAs: `Minta Growth Audit`, `Request a Growth Audit`, `Diagnosa Growth Saya`, `See the Growth System`.

### Chips

| Variant | Use |
|---|---|
| `chip-ghost` | Neutral capabilities/service tags |
| `chip-gold` | Featured offer/CTA label; max 1 per section |
| `chip-navy` | Dark/navy surfaces only |
| `chip-signal` | Positive metrics/proof |
| `chip-error` | Diagnostic risk/bottleneck |

### Cards

Canonical base: `.sys-card`.

Patterns:

- Service/pain card: pain question → service title → capability chips.
- Proof card: brand/result → short proof paragraph.
- Metric card: icon tile → big mono metric → label/caption.
- Diagnostic card: bottleneck/risk signals with gold/error/signal semantics.
- Case-study feature card: navy proof panel + white content panel.
- Form card: white surface, clear field labels, inline status/success states.

### Navigation/Shell

- Navbar/footer/sticky CTA should come from one shared source, not copied per page.
- Header nav labels stay English on both ID and EN versions.
- CTA localizes: `Minta Growth Audit` / `Request a Growth Audit`.

### Icons

- Lucide-style line icons only.
- `fill="none"`, round caps/joins, stroke width 2.
- Do not use emoji or filled app-style icons in public UI.

## 10. Content/Copy System Summary

- Voice: direct, practical, confident, owner/operator-to-owner/operator.
- Default language: Bahasa Indonesia for owner-facing copy.
- Keep natural English e-commerce terms: ROAS, CAC, GMV, NPD, creative fatigue, growth system, Growth Audit, bottleneck, marketplace, dashboard, retention, marketing cost ratio, KOL.
- Use `Kami` for Griity; address reader as `Anda`.
- Avoid: `360 solution`, `one-stop`, `unlock potential`, `explosive growth`, `guaranteed ROAS`, `growth rhythm`.

## 11. Organizational Extension Rules

### Website and landing pages
Use the exact current token/component direction. Prioritize CTA clarity and diagnostic proof.

### Decks and reports
Use navy cover/divider slides, warm off-white content slides, mono section labels, big proof metrics, and restrained gold accents.

### Admin/dashboard UI
Use the same tokens but increase density carefully. Tables should use navy headers/labels, warm surface backgrounds, signal/error status chips, and clear empty states.

### Social/content assets
Use large Plus Jakarta Sans headlines, mono category labels, navy/gold accents, and proof/diagnostic framing. Avoid motivational quote templates.

## 12. Anti-Slop Rules

Do not use:

- rainbow palettes;
- glassmorphism by default;
- generic SaaS cards with icons everywhere;
- emoji in public UI;
- fake dashboards and arbitrary numbers;
- generic stock photos (handshake/laptop/office clichés);
- excessive gradients outside hero/CTA;
- filled icons;
- vague labels like “Optimize”, “Scale”, “Insights” without content.

## 13. Implementation Source of Truth

- Live CSS: `references/griity-v3.css`.
- Shared shell: `references/shell-v3.js`.
- Visual reference: `references/design-system.html`.
- Copy reference: `references/copy-rules.html`.

If values conflict, prioritize the live CSS and current brand docs, then update docs intentionally.
