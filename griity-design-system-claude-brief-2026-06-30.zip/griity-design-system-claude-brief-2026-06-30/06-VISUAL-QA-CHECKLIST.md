# GRIITY Visual QA Checklist

Use this before accepting any Griity design-system or website visual work.

## Static checks

- [ ] Uses navy/gold/warm surface palette.
- [ ] Uses Plus Jakarta Sans + IBM Plex Mono correctly.
- [ ] Uses system cards, chips, buttons where possible.
- [ ] Uses line-only icons; no emoji in public UI.
- [ ] New colors/tokens are documented.
- [ ] ID and EN variants are visually synced where applicable.
- [ ] No internal design docs are published as public website assets.

## Browser/design checks

- [ ] Primary viewport looks intentional and non-generic.
- [ ] CTA hierarchy is clear; one primary action per section.
- [ ] Mobile spacing and sticky CTA remain usable.
- [ ] Cards are not overfilled with text.
- [ ] Dark sections are not overused.
- [ ] Empty media/social placeholders are removed or populated.
- [ ] Form success/error/loading states are obvious.

## Brand/copy checks

- [ ] Voice is direct, practical, diagnostic.
- [ ] No banned generic agency/SaaS phrases.
- [ ] Bahasa-first copy is natural, not stiff translation.
- [ ] Growth claims are evidence-based and not overpromised.

## Engineering checks for website implementation

- [ ] CSS references token values, not scattered raw hex.
- [ ] Shared shell/nav/footer/sticky CTA remains single-source.
- [ ] Console has no JS errors.
- [ ] Routes/assets return HTTP 200.
- [ ] No runtime dependency on unapproved external image/CDN sources.
