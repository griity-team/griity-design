# GRIITY Component Patterns

## Core classes from live website

| Class | Role |
|---|---|
| `.sys-card` | Standard rounded white card with subtle border/shadow |
| `.chip` | Base mono uppercase chip |
| `.chip-ghost` | Neutral ghost chip |
| `.chip-gold` | Gold/accent chip |
| `.chip-navy` | Dark/navy hero chip |
| `.chip-signal` | Positive/success chip |
| `.chip-error` | Error/risk/negative chip |
| `.kicker` | Mono section kicker |
| `.microlabel` | Tiny mono label/caption |
| `.btn-primary` | Gold primary CTA |
| `.btn-ghost-navy` | Light-section ghost button |
| `.btn-ghost-dark` | Dark-section ghost button |
| `.flow-divider` | Vertical flow separator |
| `.grid-dots-dark` | Dark dotted grid background |

## Website pattern layer

1. **Hero sections** — navy gradient, grid dots, gold emphasis, primary/ghost CTA pair.
2. **CTA bands** — footer/section CTA with navy background and one gold action.
3. **Proof/system cards** — `.sys-card`, mono labels, line icons.
4. **Diagnostic cards** — use `--signal` / `--error` semantics for positive/negative states.
5. **Case-study stage cards/charts** — proof-driven, no fake metrics.
6. **Tool/calculator forms** — consistent input cards, output cards, metric labels.
7. **Media/social proof cards** — populated with real first-party assets; avoid empty placeholders.
8. **Admin UI primitives** — tables, filters, empty states, and status chips should reuse navy/gold/signal/error semantics.

## New component rule

Before adding a new visual component:

1. Check if an existing class solves it.
2. If page-specific, keep CSS local and documented.
3. If repeated across two or more pages, promote it into `griity-v3.css` and update the design-system docs.

## Icon rules

- SVG/Lucide-style line icons only.
- `fill="none"`, round caps/joins, stroke width 2.
- No emoji in public website UI.
