# GRIITY Design System Brief — for Claude Design

**Read this first.** This ZIP is a complete briefing pack for Claude Design / Claude Code to create or extend the official Griity organization design system.

## Goal

Build a durable, organization-level design system for **Griity** based on the current live website visual language — not a generic agency/SaaS look.

Griity is an **operator-led growth partner for Indonesian D2C/e-commerce brands**. The design must communicate:

- strategic clarity, not decoration;
- premium-but-practical business credibility;
- growth/operator mindset;
- data-aware lead generation and diagnostic thinking;
- Bahasa-first communication with natural e-commerce English terms.

## Recommended reading order for Claude

1. `00-PROMPT-FOR-CLAUDE-DESIGN.md` — ready-to-paste master prompt.
2. `01-DESIGN-SYSTEM-SPEC.md` — complete human-readable system rules.
3. `DESIGN.md` — machine-readable token spec in Google DESIGN.md format.
4. `02-DESIGN-TOKENS.md` — token table and usage notes.
5. `03-COMPONENT-PATTERNS.md` — reusable component/layer patterns.
6. `04-COPY-VOICE-RULES.md` — brand language, CTA, banned phrases.
7. `05-IMPLEMENTATION-GUARDRAILS.md` — rules for website/repo implementation.
8. `06-VISUAL-QA-CHECKLIST.md` — acceptance checklist before calling work done.
9. `references/design-system.html` + `references/copy-rules.html` — visual/source references. Open in browser if possible.
10. `references/griity-v3.css` + `references/shell-v3.js` — actual current website source.

## What Claude should produce

Claude should produce a coherent **Griity Organization Design System** that can cover:

- website pages and landing pages;
- pitch decks and client-facing reports;
- internal dashboards/admin UI;
- lead-gen forms and growth audit flows;
- social/content assets;
- future product/service pages.

But the source of truth is still the current website baseline: **deep navy + warm off-white + gold CTA + Plus Jakarta Sans + IBM Plex Mono + operator-grade layout discipline**.

## Non-negotiables

- Do **not** invent a new brand direction unless explicitly requested.
- Do **not** use generic SaaS glassmorphism, rainbow gradients, emoji, or stock-photo cliché.
- Use **Plus Jakarta Sans** for UI/body/headlines and **IBM Plex Mono** only for metrics, chips, kickers, microlabels, and code-like labels.
- Use Griity's navy/gold/warm surface palette.
- Keep ID/EN design parity; Bahasa-first for owner-facing copy.
- Primary CTA concept: **Growth Audit** / diagnosis before scaling budget.
- Never promise guaranteed ROAS or unrealistic growth.

## Included source references

- `references/griity-v3.css` — live design tokens/components.
- `references/shell-v3.js` — shared nav/footer/sticky CTA source.
- `references/design-system.html` — visual component board.
- `references/copy-rules.html` — brand voice/copy rules board.
- `assets/logo_griity.png` — logo reference.

## Package status

Generated from current Griity website baseline on **2026-06-30 UTC** at repo commit `6a7d774`.
