# GRIITY Copy & Voice Rules

## Voice

Griity should sound like a smart Marketing Operator talking to a founder — not a consultant, not a SaaS product, not a generic agency.

Griity sounds:

- direct and practical;
- confident without arrogance;
- owner/operator-to-owner/operator;
- data-aware but human;
- diagnostic;
- premium but not stiff.

## Language direction

- Bahasa Indonesia is default for owner-facing copy.
- Keep natural business/e-commerce terms in English: ROAS, CAC, GMV, NPD, creative fatigue, growth system, Growth Audit, bottleneck, marketplace, dashboard, retention, marketing cost ratio, KOL.
- Use `Kami` for Griity and `Anda` for the reader.
- Header nav labels stay English on both ID and EN pages.
- CTA button localizes: `Minta Growth Audit` / `Request a Growth Audit`.

## CTA system

| Placement | Primary CTA | Secondary CTA | Micro text |
|---|---|---|---|
| Hero ID | Minta Growth Audit | See the Growth System | GRATIS · TANPA KOMITMEN |
| Hero EN | Request a Growth Audit | Take the 30-sec Self-Check | FREE · NO COMMITMENT |
| Self-check | Diagnosa Growth Saya | — | — |
| Audit section | Minta Growth Audit | — | GRATIS · TANPA KOMITMEN · DIAGNOSIS DULU |
| Footer/mobile sticky | Minta Audit / Minta Growth Audit | — | GRATIS · TANPA KOMITMEN |

## Banned / avoid phrases

- 360 solution
- one-stop marketing
- unlock potential
- explosive growth
- guaranteed ROAS
- growth rhythm
- integrated solution
- full-service agency
- best-in-class
- actionable insights when it does not say what action

## Section language rules

- **Hero:** Bahasa-led, one clear growth problem/promise.
- **Services/pain cards:** Bahasa pain question, English service title, English capability chips.
- **Case studies/proof:** English titles and metrics often read more credible; CTA returns to Bahasa.
- **Growth Audit:** Bahasa/hybrid diagnostic framing.
- **About/Careers:** Bahasa-led warmth, English section kickers.
- **Footer:** Bahasa CTA, English mono tagline.
