# Implementation Guardrails

## Public website rules

- Keep design-time/internal docs out of public website assets.
- Use staging first for website code changes.
- Production deploy requires explicit approval.
- ID and EN variants must stay visually synced.
- Navbar/footer/sticky CTA should come from one shared shell/component source.
- Prefer `griity-v3.css` tokens/components over one-off raw CSS.
- Use Plus Jakarta Sans + IBM Plex Mono only unless a future brand decision changes the type system.
- No emoji in public website UI.
- Use first-party/local assets where possible; avoid runtime external image/CDN dependencies.

## Files in this package that are source references only

- `references/design-system.html`
- `references/copy-rules.html`
- `README.md`
- all markdown brief files

These are for Claude/design-team reading, not for publishing to `/public/site`.

## Current live website structure

The website currently has 20 canonical public HTML files:

- ID + EN homepage
- services
- case studies
- about
- tools
- calculators
- launch media plan
- blog
- careers
- audit

Current shared implementation references:

- `references/griity-v3.css`
- `references/shell-v3.js`

## Design-system expansion rules

When extending the system into decks/admin/social:

1. Preserve brand tokens.
2. Define any new component or token role explicitly.
3. Keep proof/metric modules honest — no fake data.
4. Use signal/error semantics consistently.
5. Run visual QA before calling work done.
