# GRIITY Design Tokens

## Canonical live source

`references/griity-v3.css`

## Core tokens

| Token | Value | Usage |
|---|---:|---|
| `--bg` | `#F7F4EE` | Warm page background |
| `--surface` | `#FFFFFF` | Cards/surfaces |
| `--navy` | `#1A2C50` | Primary brand navy / text |
| `--navy-deep` | `#111E38` | Deep hero/navy gradient |
| `--ink` | `#1A2C50` | Heading/strong body text |
| `--body-c` | `#4A5874` | Body text |
| `--muted` | `#8593AC` | Captions/micro labels |
| `--line` | `rgba(26,44,80,0.10)` | Standard border line |
| `--line-strong` | `rgba(26,44,80,0.16)` | Stronger divider/border |
| `--gold` | `#F6A404` | Primary CTA/accent |
| `--gold-deep` | `#D98E02` | Gold text/accent state |
| `--signal` | `#1F8A5B` | Positive/success metric |
| `--error` | `#E0533D` | Error/risk/negative diagnostic |
| `--chip-bg` | `rgba(26,44,80,0.045)` | Ghost chip background |

## Typography tokens

| Role | Font | Usage |
|---|---|---|
| UI/body/headings | Plus Jakarta Sans | Main website typography |
| Mono labels/metrics | IBM Plex Mono | Kicker, microlabel, chip, metric labels |

## Export files

- `tokens/griity.tokens.json` — structured token list.
- `tokens/tailwind.theme.json` — Tailwind extension starter.
- `DESIGN.md` — Google DESIGN.md-compatible spec for agent consumption.

## Usage rules

- Prefer `var(--token)` over raw hex in code.
- If a visual value repeats across two or more pages, promote it to the token registry.
- Do not add new brand colors without naming the role and adding QA/accessibility notes.
- Keep button/card/chip radius consistent unless there is a deliberate documented exception.
