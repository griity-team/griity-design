# Prompt for Claude Design — Create Griity Organization Design System

You are Claude Design acting as a senior brand systems designer and design-systems architect.

## Assignment

Create a full **organization-level design system for Griity**, using this package as the source of truth. The system must extend the current Griity website visual language into a reusable design system for the whole organization.

## Read before designing

Read these files in order:

1. `README.md`
2. `01-DESIGN-SYSTEM-SPEC.md`
3. `DESIGN.md`
4. `02-DESIGN-TOKENS.md`
5. `03-COMPONENT-PATTERNS.md`
6. `04-COPY-VOICE-RULES.md`
7. `05-IMPLEMENTATION-GUARDRAILS.md`
8. `06-VISUAL-QA-CHECKLIST.md`
9. `references/design-system.html`
10. `references/copy-rules.html`
11. `references/griity-v3.css`

## Brand context

Griity is an Indonesian growth marketing and creative agency/operator partner. It helps D2C/e-commerce brands diagnose bottlenecks across ads, creative, marketplace, NPD/Product Launch Strategy, stock, margin, retention, and funnel execution before scaling spend.

The brand should feel:

- operator-grade;
- premium but practical;
- strategic and data-aware;
- direct, founder/operator-to-founder/operator;
- Indonesian market-native;
- credible for both UMKM/SMB and larger brands.

## Current design posture

- Deep navy foundations: `#1A2C50`, `#111E38`.
- Warm off-white background: `#F7F4EE`.
- Gold CTA/accent: `#F6A404`, `#D98E02`.
- White cards with subtle border/shadow.
- Plus Jakarta Sans for body/headline/UI.
- IBM Plex Mono for microlabels, kickers, chips, metrics.
- Lucide-style line icons only.
- No emoji in public UI.
- Layout should support evidence-led growth diagnosis and clear CTA flow.

## Deliverable requested from Claude

Produce a polished design-system artifact that includes:

1. Brand foundations and visual principles.
2. Color system with roles, accessibility guidance, and dark/light applications.
3. Typography scale and usage rules.
4. Layout, spacing, grid, radii, and surface/elevation system.
5. Component system for:
   - buttons;
   - chips/tags;
   - cards;
   - forms;
   - nav/footer/sticky CTA;
   - diagnostic modules;
   - metric/proof cards;
   - case-study cards;
   - social/media cards;
   - admin/dashboard/table primitives.
6. Content/copy guidelines aligned to Griity's Bahasa-first operator voice.
7. Do/don't rules with anti-slop examples.
8. Example screens or component board suitable for internal team handoff.
9. Implementation notes for frontend engineers.

## Critical constraints

- Preserve the Griity look; do not rebrand.
- Do not use generic agency wording such as “360 solution”, “one-stop”, “unlock potential”, “guaranteed ROAS”, “explosive growth”.
- Do not use filled icons, emoji, glassmorphism, or decorative gradients outside hero/CTA contexts.
- Do not create fake metrics or unverifiable claims.
- For website work, ID and EN versions must stay visually synced.
- For public website implementation, internal docs like this package must never be published under `public/site`.

## Preferred output style

High clarity, structured, designer-readable, engineer-actionable. Include exact token names/values and examples. Treat this as a real operating design system, not inspiration moodboard copy.
