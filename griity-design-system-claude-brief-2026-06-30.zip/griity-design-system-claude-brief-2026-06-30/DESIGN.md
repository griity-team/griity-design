---
version: alpha
name: Griity
description: Operator-grade growth marketing design system for Indonesian D2C and e-commerce brands.
colors:
  bg: "#F7F4EE"
  surface: "#FFFFFF"
  navy: "#1A2C50"
  navyDeep: "#111E38"
  ink: "#1A2C50"
  body: "#4A5874"
  muted: "#8593AC"
  gold: "#F6A404"
  goldDeep: "#D98E02"
  signal: "#1F8A5B"
  error: "#E0533D"
  primary: "#1A2C50"
  secondary: "#4A5874"
  tertiary: "#F6A404"
  neutral: "#F7F4EE"
typography:
  h1:
    fontFamily: Plus Jakarta Sans
    fontSize: 3.5rem
    fontWeight: 800
    lineHeight: 1.08
    letterSpacing: "-0.02em"
  h2:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.5rem
    fontWeight: 800
    lineHeight: 1.15
    letterSpacing: "-0.015em"
  h3:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: 800
    lineHeight: 1.3
    letterSpacing: "-0.01em"
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: 400
    lineHeight: 1.7
  kicker:
    fontFamily: IBM Plex Mono
    fontSize: 0.75rem
    fontWeight: 600
    lineHeight: 1.2
    letterSpacing: "0.18em"
  microlabel:
    fontFamily: IBM Plex Mono
    fontSize: 0.625rem
    fontWeight: 600
    lineHeight: 1.2
    letterSpacing: "0.14em"
  metric:
    fontFamily: IBM Plex Mono
    fontSize: 3.5rem
    fontWeight: 600
    lineHeight: 1
spacing:
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  2xl: 48px
  3xl: 64px
rounded:
  sm: 8px
  md: 14px
  lg: 18px
  xl: 28px
  pill: 999px
components:
  button-primary:
    backgroundColor: "{colors.gold}"
    textColor: "{colors.navy}"
    typography: "{typography.body-md}"
    rounded: "{rounded.md}"
    padding: 14px
  button-primary-hover:
    backgroundColor: "#FFB41E"
    textColor: "{colors.navy}"
    rounded: "{rounded.md}"
    padding: 14px
  button-ghost-navy:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.navy}"
    typography: "{typography.body-md}"
    rounded: "{rounded.md}"
    padding: 14px
  card-system:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.ink}"
    rounded: "{rounded.lg}"
    padding: 24px
  chip-ghost:
    backgroundColor: "#F0F1F4"
    textColor: "{colors.body}"
    typography: "{typography.microlabel}"
    rounded: "{rounded.pill}"
    padding: 8px
  chip-gold:
    backgroundColor: "#FFF1D6"
    textColor: "{colors.goldDeep}"
    typography: "{typography.microlabel}"
    rounded: "{rounded.pill}"
    padding: 8px
  chip-signal:
    backgroundColor: "#EAF5F0"
    textColor: "{colors.signal}"
    typography: "{typography.microlabel}"
    rounded: "{rounded.pill}"
    padding: 8px
  chip-error:
    backgroundColor: "#FCEDEA"
    textColor: "{colors.error}"
    typography: "{typography.microlabel}"
    rounded: "{rounded.pill}"
    padding: 8px
---

## Overview

Griity's design system is built for an operator-led Indonesian growth partner. It should feel strategic, credible, premium-but-practical, and data-aware without looking like a generic SaaS landing page.

Core visual language: deep navy foundations, warm off-white backgrounds, gold conversion accents, white system cards, Plus Jakarta Sans typography, IBM Plex Mono micro-labels, and line-only icons.

## Colors

- **Navy (`#1A2C50`)** is the trust anchor: headings, navigation, primary text, dark sections.
- **Navy Deep (`#111E38`)** adds depth to hero/CTA gradients.
- **Gold (`#F6A404`)** is the primary CTA/accent color. Use sparingly and intentionally.
- **Gold Deep (`#D98E02`)** is the text/accent state for kickers and gold labels.
- **Warm BG (`#F7F4EE`)** keeps pages premium and less sterile than pure white.
- **Surface (`#FFFFFF`)** is used for cards, forms, and raised panels.
- **Signal (`#1F8A5B`)** indicates positive proof or success.
- **Error (`#E0533D`)** indicates risks, blockers, validation errors, or negative diagnostics.

## Typography

Use **Plus Jakarta Sans** for UI, body, navigation, headings, and buttons.

Use **IBM Plex Mono** only for system-like elements: kickers, microlabels, chips, metrics, and code-like labels. Do not use mono for body paragraphs.

Headlines should be confident and compact. Body text should be readable and practical, usually no more than two sentences per paragraph on mobile.

## Layout

Use max-width container layouts with generous but disciplined spacing. Alternate card grids with narrative lists, diagnostic modules, proof strips, and CTA bands to avoid repetitive SaaS grids.

Warm off-white is the default section background. Navy sections are reserved for hero, audit CTA, footer CTA, and selected proof moments. Never stack too many dark sections in sequence.

## Elevation & Depth

Depth is subtle. Cards use white surfaces, a low-contrast navy border, and a restrained long shadow. Avoid glassmorphism, heavy drop shadows, and decorative blur effects.

## Shapes

Cards use 18px radius by default. Buttons use 14px radius. Chips use full pill radius. Large feature panels may use 24–28px radius.

## Components

Primary components:

- **Button Primary:** gold background + navy text. Use for the main Growth Audit or next-step CTA.
- **Button Ghost Navy:** secondary action on light surfaces.
- **Button Ghost Dark:** secondary action on navy surfaces.
- **System Card:** white card with subtle border/shadow.
- **Chips:** mono uppercase labels for services, proof, status, or diagnostics.
- **Metric Cards:** large mono numbers with concise proof labels.
- **Diagnostic Cards:** bottleneck/risk modules using gold, signal, and error semantics.
- **Case Study Cards:** navy proof panel + white content panel.
- **Forms:** white surfaces, clear labels, strong success/error states.

## Do's and Don'ts

Do:

- Use navy/gold/warm off-white consistently.
- Use system cards and chips before inventing new primitives.
- Use line-only icons.
- Keep CTA copy specific to Growth Audit/diagnosis.
- Keep Bahasa-first copy for owner-facing sections.

Don't:

- Add emoji to public UI.
- Use generic SaaS gradients or glass effects.
- Use fake metrics or unverifiable claims.
- Use filled icons.
- Use phrases like “360 solution”, “one-stop”, “unlock potential”, “explosive growth”, or “guaranteed ROAS”.
