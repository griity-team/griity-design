/* ============================================================
   Griity v3 — shared shell (navbar, footer, sticky mobile CTA)
   Language-aware. Load as a normal <script src> in <head>.
   Usage in page:
     <div id="nav"></div>  <script>GRV3.nav('services','id')</script>
     <div id="footer"></div> <script>GRV3.footer('id')</script>
     <div id="sticky"></div> <script>GRV3.sticky('id')</script>
   lang = 'id' (default) | 'en'
   ============================================================ */
(function () {
    const IMG = '../public/assets/image/';
    const SELF_CHECK_STORAGE_KEY = 'griity:self-check';

    // Page registry: id -> { id-file, en-file, label-id, label-en }
    const PAGES = [
        { key: 'services',     idf: '/services',     enf: '/en/services',     id: 'Services',      en: 'Services' },
        { key: 'case-studies', idf: '/case-studies', enf: '/en/case-studies', id: 'Case Studies',  en: 'Case Studies' },
        { key: 'about',        idf: '/about',        enf: '/en/about',        id: 'About',         en: 'About' },
        { key: 'tools',        idf: '/tools',        enf: '/en/tools',        id: 'Tools',         en: 'Tools' },
        { key: 'blog',         idf: '/blog',         enf: '/en/blog',         id: 'Blog',          en: 'Blog' },
        { key: 'careers',      idf: '/careers',      enf: '/en/careers',      id: 'Careers',       en: 'Careers' },
    ];
    const HOME = { id: '/', en: '/en' };
    const AUDIT = { id: '/audit', en: '/en/audit' };

    const T = {
        id: { audit: 'Minta Growth Audit', home: '/',
              footerCta: 'Siap scale lebih sustainable?', footerSub: 'Cerita ke kami posisi brand Anda sekarang. Kami mulai dari cari tahu lever growth mana yang perlu dibenahi duluan.',
              hq: 'Office', news: 'Ikuti insight growth dari para Marketing Operator', newsSub: 'Catatan praktis soal growth D2C & marketplace untuk brand owner Indonesia.',
              name: 'Nama', email: 'Email Anda', send: 'Hubungi Kami', rights: 'Hak cipta dilindungi.', tagline: 'GROWTH SEBAGAI SATU SISTEM',
              stickyT: 'Mulai dari diagnosis', stickyS: 'GRATIS · TANPA KOMITMEN', stickyB: 'Minta Audit' },
        en: { audit: 'Request a Growth Audit', home: '/en',
              footerCta: 'Ready to scale more sustainably?', footerSub: "Tell us where your brand is today. We start by finding which growth levers need attention first.",
              hq: 'Office', news: 'Growth insights, straight from Marketing Operators', newsSub: 'Practical notes on D2C and marketplace growth for Indonesian brand owners.',
              name: 'Name', email: 'Your email', send: 'Contact Us', rights: 'All rights reserved.', tagline: 'GROWTH AS A CONNECTED SYSTEM',
              stickyT: 'Start with diagnosis', stickyS: 'FREE · NO COMMITMENT', stickyB: 'Request Audit' },
    };

    function nav(active, lang) {
        lang = lang === 'en' ? 'en' : 'id';
        const t = T[lang];
        const file = p => lang === 'en' ? p.enf : p.idf;
        const lbl  = p => lang === 'en' ? p.en : p.id;
        const links = PAGES.map(p => {
            const on = active === p.key;
            return `<a href="${file(p)}" class="text-[15px] ${on ? 'font-bold text-[#1A2C50]' : 'font-medium text-[#4A5874]'} hover:text-[#1A2C50] transition">${lbl(p)}</a>`;
        }).join('');
        const mlinks = PAGES.map(p => `<a href="${file(p)}" class="block font-medium text-[#1A2C50]">${lbl(p)}</a>`).join('');
        // language switch target = same logical page in the other language
        const cur = PAGES.find(p => p.key === active);
        const switchHref = lang === 'en'
            ? (cur ? cur.idf : (active === 'audit' ? AUDIT.id : HOME.id))
            : (cur ? cur.enf : (active === 'audit' ? AUDIT.en : HOME.en));
        const switchLabel = lang === 'en' ? 'ID' : 'EN';
        const auditFile = lang === 'en' ? AUDIT.en : AUDIT.id;

        return `
        <nav x-data="{ isOpen: false }" class="fixed top-0 w-full z-50" style="background: rgba(247,244,238,0.85); backdrop-filter: blur(12px); border-bottom: 1px solid var(--line);">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center h-16">
                    <a href="${t.home}" class="flex items-center gap-3"><img src="${IMG}logo_griity.png" alt="Griity Logo" class="h-8"></a>
                    <div class="hidden md:flex items-center gap-7 flex-1 justify-end">
                        ${links}
                        <a href="${switchHref}" class="text-[13px] font-semibold text-[#8593AC] hover:text-[#1A2C50] transition border border-[rgba(26,44,80,0.16)] rounded-lg px-2.5 py-1" title="${switchLabel === 'EN' ? 'English version' : 'Versi Bahasa'}">${switchLabel}</a>
                        <a href="${auditFile}" class="btn-primary px-5 py-2.5 text-sm inline-flex items-center gap-2">${t.audit}</a>
                    </div>
                    <button @click="isOpen = !isOpen" class="md:hidden text-[#1A2C50]" aria-label="Toggle menu">
                        <svg x-show="!isOpen" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>
                        <svg x-show="isOpen" x-cloak xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                    </button>
                </div>
                <div x-show="isOpen" x-cloak x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0 -translate-y-2" x-transition:enter-end="opacity-100 translate-y-0" class="md:hidden pb-4 space-y-3">
                    ${mlinks}
                    <div class="flex items-center gap-3 pt-1">
                        <a href="${switchHref}" class="text-[13px] font-semibold text-[#8593AC] border border-[rgba(26,44,80,0.16)] rounded-lg px-2.5 py-1">${switchLabel}</a>
                    </div>
                    <a href="${auditFile}" class="btn-primary block text-center px-6 py-3">${t.audit}</a>
                </div>
            </div>
        </nav>`;
    }

    function footer(lang) {
        lang = lang === 'en' ? 'en' : 'id';
        const t = T[lang];
        const auditFile = lang === 'en' ? AUDIT.en : AUDIT.id;
        const social = [
            { url: 'https://www.linkedin.com/company/griity/', icon: '<path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect width="4" height="12" x="2" y="9"/><circle cx="4" cy="4" r="2"/>' },
            { url: 'https://www.youtube.com/@griityid', icon: '<path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"/><path d="m10 15 5-3-5-3z"/>' },
            { url: 'https://www.instagram.com/griityid/', icon: '<rect width="20" height="20" x="2" y="2" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>' },
        ];
        return `
        <footer>
            <div class="py-10 lg:py-14 px-4 sm:px-6 lg:px-8">
                <div class="max-w-7xl mx-auto sys-card relative overflow-hidden" style="border-radius: 28px; background: var(--navy); border-color: rgba(255,255,255,0.08);">
                    <div class="absolute inset-0 grid-dots-dark opacity-40"></div>
                    <div class="absolute -top-20 -right-20 w-72 h-72 rounded-full" style="background: radial-gradient(circle, rgba(246,164,4,0.2), transparent 65%);"></div>
                    <div class="relative z-10 px-8 py-10 lg:px-16 lg:py-12 flex flex-col md:flex-row items-center justify-between gap-8 text-center md:text-left">
                        <div>
                            <p class="kicker mb-3" style="color: var(--gold);">${lang === 'en' ? 'Next Step' : 'Langkah Berikutnya'}</p>
                            <h2 class="text-3xl lg:text-4xl font-extrabold text-white tracking-tight mb-2">${t.footerCta}</h2>
                            <p class="text-lg" style="color:#B9C4DA;">${t.footerSub}</p>
                        </div>
                        <a href="${auditFile}" class="btn-primary px-9 py-4 text-lg whitespace-nowrap">${t.audit}</a>
                    </div>
                </div>
            </div>
            <div class="px-4 sm:px-6 lg:px-8 pb-10">
                <div class="max-w-7xl mx-auto pt-10" style="border-top: 1px solid var(--line);">
                    <div class="grid lg:grid-cols-2 gap-14 mb-10">
                        <div class="space-y-7">
                            <img src="${IMG}logo_griity.png" alt="Griity Logo" class="h-8">
                            <div class="space-y-4">
                                <div class="flex gap-3 items-start">
                                    <svg class="w-5 h-5 mt-1 shrink-0" style="color: var(--gold-deep);" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                                    <div>
                                        <h4 class="font-bold text-base mb-1">Office</h4>
                                        <p class="leading-relaxed max-w-sm text-[15px]" style="color: var(--body-c);">Gedung Grand Slipi Tower Lt.42, Unit G-H<br>Jl. Letjen. S. Parman Kav. 22-24<br>Palmerah, Jakarta Barat</p>
                                    </div>
                                </div>
                                <div class="flex gap-3 items-start">
                                    <svg class="w-5 h-5 mt-1 shrink-0" style="color: var(--gold-deep);" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                                    <div>
                                        <h4 class="font-bold text-base mb-1">Headquarters</h4>
                                        <p class="leading-relaxed max-w-sm text-[15px]" style="color: var(--body-c);">Jl. Surya Utama Blok 2 no J9<br>RT.13/RW.5, Kedoya Utara<br>Kec. Kb. Jeruk, Jakarta Barat</p>
                                    </div>
                                </div>
                                <div class="flex gap-3 items-center">
                                    <svg class="w-5 h-5" style="color: var(--gold-deep);" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                                    <a href="mailto:jeril@griity.id" class="font-semibold hover:underline" style="color: var(--ink);">jeril@griity.id</a>
                                </div>
                            </div>
                            <div class="flex gap-3">${social.map(s => `<a href="${s.url}" target="_blank" rel="noopener" class="w-10 h-10 rounded-xl flex items-center justify-center transition-all" style="background: var(--chip-bg); border: 1px solid var(--line); color: var(--navy);" onmouseover="this.style.background='var(--gold)'" onmouseout="this.style.background='var(--chip-bg)'"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${s.icon}</svg></a>`).join('')}</div>
                        </div>
                        <div>
                            <h3 class="text-xl font-extrabold mb-2 tracking-tight">${t.news}</h3>
                            <p class="text-sm mb-6" style="color: var(--muted);">${t.newsSub}</p>
                            <form class="space-y-4" onsubmit="return GRV3.newsletterSubmit(event, '${lang}');">
                                <div class="grid md:grid-cols-2 gap-4">
                                    <input name="name" type="text" required placeholder="${t.name}" class="w-full rounded-xl px-4 py-3.5 text-[15px] outline-none transition-all bg-white" style="border: 1px solid var(--line-strong); color: var(--ink);">
                                    <input name="email" type="email" required placeholder="${t.email}" class="w-full rounded-xl px-4 py-3.5 text-[15px] outline-none transition-all bg-white" style="border: 1px solid var(--line-strong); color: var(--ink);">
                                </div>
                                <button type="submit" class="group w-full md:w-auto inline-flex justify-center items-center gap-2 px-8 py-3.5 rounded-xl font-bold text-white transition-all" style="background: var(--navy);">${t.send}
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="group-hover:translate-x-1 transition-transform"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
                                </button>
                                <p data-newsletter-status aria-live="polite" class="text-sm font-semibold min-h-[1.25rem]" style="color: var(--gold-deep);"></p>
                            </form>
                        </div>
                    </div>
                    <div class="pt-8 flex flex-col md:flex-row justify-between items-center gap-3 text-sm" style="border-top: 1px solid var(--line); color: var(--muted);">
                        <p>&copy; 2026 Griity Agency. ${t.rights}</p>
                        <p class="mono text-xs">${t.tagline}</p>
                    </div>
                </div>
            </div>
        </footer>`;
    }

    function sticky(lang) {
        lang = lang === 'en' ? 'en' : 'id';
        const t = T[lang];
        const auditFile = lang === 'en' ? AUDIT.en : AUDIT.id;
        return `
        <div class="md:hidden fixed bottom-0 inset-x-0 z-40 px-4 py-3 flex items-center gap-3" style="background: rgba(17,30,56,0.95); backdrop-filter: blur(8px); border-top: 1px solid rgba(255,255,255,0.1);">
            <div class="flex-1 min-w-0">
                <p class="text-white text-sm font-bold leading-tight">${t.stickyT}</p>
                <p class="mono text-[10px]" style="color:#8593AC;">${t.stickyS}</p>
            </div>
            <a href="${auditFile}" class="btn-primary px-5 py-3 text-sm whitespace-nowrap">${t.stickyB}</a>
        </div>`;
    }


    async function postJson(url, payload) {
        const res = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify(payload),
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.message || 'Submit failed');
        return data;
    }

    function formStatus(form, selector, message, isError = false) {
        let status = form.querySelector(selector);
        if (!status) {
            status = document.createElement('p');
            status.setAttribute('aria-live', 'polite');
            status.className = 'text-sm font-semibold mt-3';
            form.appendChild(status);
        }
        status.textContent = message;
        status.style.color = isError ? '#B42318' : 'var(--gold-deep)';
    }


    function collectSelfCheckSelections(root = document) {
        const scope = root && root.querySelectorAll ? root : document;
        return Array.from(scope.querySelectorAll('.sc-item[aria-pressed="true"]'))
            .map(item => (item.getAttribute('data-selfcheck-title') || item.textContent || '').trim())
            .filter(Boolean)
            .slice(0, 12);
    }

    function storeSelfCheckSelections(root = document) {
        const selections = collectSelfCheckSelections(root);
        try {
            localStorage.setItem(SELF_CHECK_STORAGE_KEY, JSON.stringify(selections));
        } catch (e) {
            // Ignore storage blockers; audit submit continues without self-check context.
        }
        return selections;
    }

    function readStoredSelfCheckSelections() {
        try {
            const parsed = JSON.parse(localStorage.getItem(SELF_CHECK_STORAGE_KEY) || '[]');
            return Array.isArray(parsed)
                ? parsed.filter(item => typeof item === 'string' && item.trim() !== '').slice(0, 12)
                : [];
        } catch (e) {
            return [];
        }
    }

    function clearStoredSelfCheckSelections() {
        try {
            localStorage.removeItem(SELF_CHECK_STORAGE_KEY);
        } catch (e) {
            // Ignore storage blockers.
        }
    }

    async function newsletterSubmit(event, lang) {
        event.preventDefault();
        const form = event.currentTarget;
        const button = form.querySelector('button[type="submit"]');
        const old = button ? button.innerHTML : '';
        formStatus(form, '[data-newsletter-status]', '', false);
        if (button) { button.disabled = true; button.textContent = lang === 'en' ? 'Sending...' : 'Mengirim...'; }
        try {
            const fd = new FormData(form);
            await postJson('/api/newsletter', { name: fd.get('name'), email: fd.get('email') });
            form.reset();
            formStatus(form, '[data-newsletter-status]', lang === 'en' ? 'Thank you. We will send growth insights to your inbox.' : 'Terima kasih. Insight growth akan kami kirim ke email Anda.');
        } catch (e) {
            formStatus(form, '[data-newsletter-status]', e.message || (lang === 'en' ? 'Submit failed.' : 'Gagal mengirim.'), true);
        } finally {
            if (button) { button.disabled = false; button.innerHTML = old; }
        }
        return false;
    }


    async function auditSubmit(event, lang) {
        event.preventDefault();
        const form = event.currentTarget;
        const button = form.querySelector('button[type="submit"]');
        const old = button ? button.innerHTML : '';
        formStatus(form, '[data-audit-status]', '', false);
        if (button) { button.disabled = true; button.textContent = lang === 'en' ? 'Submitting...' : 'Mengirim...'; }
        try {
            const fd = new FormData(form);
            const payload = {
                brand_name: fd.get('brand_name'),
                name: fd.get('name'),
                email: fd.get('email'),
                phone: fd.get('phone'),
                website: fd.get('website'),
                revenue: fd.get('revenue'),
                budget: fd.get('budget'),
                objectives: fd.getAll('objectives[]'),
                self_check: readStoredSelfCheckSelections(),
                inhouse_team: fd.getAll('inhouse_team[]'),
                service_interest: fd.get('service_interest'),
            };
            await postJson('/api/growth-audit', payload);
            clearStoredSelfCheckSelections();
            const container = form.parentElement;
            const successTemplate = container ? container.querySelector('[data-audit-success-copy]') : null;
            if (container && successTemplate) {
                container.innerHTML = successTemplate.innerHTML;
            } else {
                form.reset();
                formStatus(form, '[data-audit-status]', lang === 'en' ? 'Your growth audit request has been submitted. Our team will reach out as soon as possible.' : 'Growth audit request Anda sudah kami terima. Tim Griity akan menghubungi Anda secepatnya.');
            }
        } catch (e) {
            formStatus(form, '[data-audit-status]', e.message || (lang === 'en' ? 'Submit failed.' : 'Gagal mengirim.'), true);
        } finally {
            if (button) { button.disabled = false; button.innerHTML = old; }
        }
        return false;
    }

    window.GRV3 = {
        IMG,
        nav: (active, lang) => { const el = document.getElementById('nav'); if (el) el.innerHTML = nav(active, lang); },
        footer: (lang) => { const el = document.getElementById('footer'); if (el) el.innerHTML = footer(lang); },
        sticky: (lang) => { const el = document.getElementById('sticky'); if (el) el.innerHTML = sticky(lang); },
        newsletterSubmit,
        auditSubmit,
        collectSelfCheckSelections,
        storeSelfCheckSelections,
        readStoredSelfCheckSelections,
    };
})();
